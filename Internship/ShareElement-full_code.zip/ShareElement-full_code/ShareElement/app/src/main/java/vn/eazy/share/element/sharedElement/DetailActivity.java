package vn.eazy.share.element.sharedElement;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import vn.eazy.share.element.R;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
    }
}
